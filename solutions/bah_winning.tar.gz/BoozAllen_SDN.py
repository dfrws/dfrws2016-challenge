"""
Copyright (c) 2016, Booz Allen Hamilton. All rights reserved.
 
Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:
 
1. Redistributions of source code must retain the above copyright notice, this list of 
conditions and the following disclaimer.
 
2. Redistributions in binary form must reproduce the above copyright notice, this list 
of conditions and the following disclaimer in the documentation and/or other materials 
provided with the distribution.
 
3. Neither the name of the copyright holder nor the names of its contributors may be 
used to endorse or promote products derived from this software without specific prior 
written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT 
SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""

import argparse
import collections
import datetime
import itertools
import mmap
import os
import re
import subprocess
import sys
import warnings
from struct import pack

try: import pandas
except ImportError:
    print('Missing required module: pandas. Exiting.')
    sys.exit()

warnings.simplefilter(action = "ignore", category = FutureWarning)
pandas.options.mode.chained_assignment = None
# small modifications to commands based on necessity of subprocess.Popen (takes list of single arguments as opposed to string)
# e.g., -o being immediately adjascent to ssl stuff in tshark commands
subproc_commands = {'volatility': {'bash': 'python {} -f {} --profile={} linux_bash',
                                   'mk_yara': ('python %s -f %s ' + # yara is different only because of inclusion of { and } in syntax
                                               '--profile=%s -p %s linux_yarascan -Y ' +
                                               '{30000000????????????????????????????????????????????????????????????????????????????????????????????????20000000}'),
                                   'bash_hash': 'python {} -f {} --profile={} linux_bash_hash',
                                   'psaux': 'python {} -f {} --profile={} linux_psaux',
                                   'pslist': 'python {} -f {} --profile={} linux_pslist',
                                   'recover_fs': 'python {} -f {} --profile={} linux_recover_filesystem --dump-dir {}'},
                    'tshark': {'initial_ssl': ('tshark -d tcp.port==6633,openflow -ossl.desegment_ssl_records:TRUE ' + 
                                               '-ossl.desegment_ssl_application_data:TRUE ' + 
                                               '-ossl.keys_list:192.168.1.1,6633,openflow,{} -r {} -Vx'),
                               'full_decrypt': ('tshark -d tcp.port==6633,openflow -ossl.desegment_ssl_records:TRUE ' + 
                                                '-ossl.desegment_ssl_application_data:TRUE -ossl.keys_list:192.168.1.1,6633,' + 
                                                'openflow,{} -ossl.keylog_file:{} -r {} -Vx')}}
SingleMap = collections.namedtuple('SingleMap', ['start', 'stop', 'type_or_range'])                                                
SingleFrame = collections.namedtuple('SingleFrame', ['dissected', 'frame_hex'])                                                
HostMap = collections.namedtuple('HostMap', ['hostname', 'ipv4', 'ipv6', 'mac', 'in_port'])
VswitchMap = collections.namedtuple('VswitchMap', ['port_number', 'mac', 'port_name'])
ControllerMap = collections.namedtuple('ControllerMap', ['name', 'ip_addr'])
DumpMap = collections.namedtuple('DumpMap', ['n_packets', 'n_bytes', 'in_port', 'dl_dst', 'actions'])

def parse_commandline():
    """Parses commandline. 
    
    @return parser.parse_args() --out, --pcap, --raw, and --vol_fn required, all others optional 
    """
    parser = argparse.ArgumentParser('AnalysiSDN')
    parser.add_argument('--out', dest='OUT', action='store', required=True, 
                        help='Full path of output directory; all output files will be saved into directory')
    parser.add_argument('--pcap', dest='PCAP', action='store', required=True, 
                        help='Full path of PCAP file')
    parser.add_argument('--raw', dest='RAW', action='store', required=True, 
                        help='Full path of raw RAM dump file')
    parser.add_argument('--vol_fn', dest='VOL_FN', action='store', required=True, 
                        help='Full path of Volatility main script ("./<volatility_path>/vol.py" by default)')
    parser.add_argument('--memory_regions', dest='REGIONS', action='store', choices=['dynamic', 'default'], default='dynamic', 
                        required=False, help='dynamic - extract regions from BIOS and map automatically, default - use previously-observed region maps')
    parser.add_argument('--profile_name', dest='PROFILE', action='store', default='LinuxFedora22-4_2_6-200x64', required=False, 
                        help='Name of profile in Volatility directory to use with RAM dump')
    parser.add_argument('--stdout_ram', dest='STDOUT_RAM', action='store_true', default=False, required=False, 
                        help='Switch to display/not display statistics related to RAM dump')
    parser.add_argument('--stdout_pcap', dest='STDOUT_PCAP', action='store_true', default=False, required=False, 
                        help='Switch to display/not display statistics related to decrypted PCAP')
    parser.add_argument('--output_format', dest='OUTPUT_FORMAT', action='store', choices=['xlsx', 'csv'], default='xlsx', required=False, 
                        help='Determines whether spreadsheet output is in xlsx or csv format') # needs to be implemented
    parser.add_argument('--remove_invalid_keys', dest='REM_INV_KEYS', action='store_true', default=False, required=False, 
                        help='Automatically delete invalid keys extracted from memory')
    parser.add_argument('--lime_file', dest='LIME_FN', action='store', required=False,
                        help='Full path of LiME-formatted memory dump; can be used to skip memory mapping process')
    parser.add_argument('--dump_filesystem', dest='DUMP_FS', action='store_true', required=False, default=False,
                        help='Switch to dump recovered filesystem to output directory')
    parser.add_argument('--keep_dtg', dest='KEEP_DTG', action='store_true', default=False, required=False, help='')
    return parser.parse_args()
	
def validate_externals(args):
    """Validate any external utilities required for script execution, e.g., strings.

    @param args Contains at minimum the location of the raw RAM dump and PCAP, the Vol script, and the output directory
    @return None If function executes successfully, all utilities/necessary files have been validated
    """
    def check_file(fn):
        if not os.access(fn, os.F_OK):
            print('Could not access {}. Please check path and re-run.'.format(fn))
            sys.exit()
        return True  
        
    print('Validating external dependencies.')
    for command in ['strings --help', 'tshark -v']:
        try: check_proc = subprocess.Popen(command.split(), shell=False, stdout=subprocess.PIPE).communicate()[0]
        except OSError: 
            print('Missing required utility: {}. Please install and re-run.'.format(command.split()[0]))
            sys.exit()
        if 'tshark' in command:
            if not re.search('2\.\d\.\d', check_proc.splitlines()[0]):
                print('Utility requires minimum TShark version 2.0.\nCurrent version: {}.\nPlease upgrade and re-run'.format(check_proc.splitlines()[0]))
                sys.exit()    
                
    for fn in [args.VOL_FN, args.RAW, args.PCAP]: check_file(fn)       
    if args.LIME_FN: check_file(args.LIME_FN)
        
    if not os.access(args.OUT, os.F_OK):
        try: os.mkdir(args.OUT)
        except Exception as e:
            print('Could not find/create output directory: {}. Please check and re-run.'.format(args.OUT))
            sys.exit()
            
    print('Successfully validated external dependencies.')    

def grab_strings(args):
    """Uses strings to grab all strings from raw RAM dump

    @param args Used for raw RAM location
    @return strings_proc.communicate Full feed of strings call
    """
    print('Grabbing strings.')
    strings_proc = subprocess.Popen('strings {}'.format(args.RAW).split(), shell=False, stdout=subprocess.PIPE)
    return strings_proc.communicate()[0]
    
def grab_insmod_info(raw_strings):
    insmod_commands = re.findall('.+insmod\s(lime)\-(\S+)\s\"{0,1}(\S+)', raw_strings)
    if not any(insmod_commands): return [None, None]
    else: return list(set(command[1] for command in insmod_commands)), list(set(command[2] for command in insmod_commands))
    
def grab_logs(raw_strings):
    """Grabs DTG|...|LOG_DESC logs, dumps to DF
    
    @param raw_strings Full dump of strings output from raw RAM dump
    @return pandas.DataFrame DF of quintet logs as DTG, SEQ_NUM, LOG_TYPE, LOG_LEVEL, and LOG_DESC
    """
    print('Generating DTG|SEQ_NUM|LOG_TYPE|LOG_LEVEL|LOG_DESC logs.')
    log_re = re.compile('(\d{4}\-\d{2}\-\d{2}T\d{2}\:\d{2}\:\d{2}\.\d{3}Z)\|(.+)\|(.+)\|(.+)\|(.+)')
    return pandas.DataFrame(log_re.findall(raw_strings), columns=['DTG', 'SEQ_NUM', 'LOG_TYPE', 'LOG_LEVEL', 'LOG_DESC'])

def convert_raw(args): 
    """Generates LiME-formatted version of raw RAM input file

    @param args Used for raw RAM location and switch on 'regions', either dynamic or default mappings
    @return output_as_lime.name Filename of validated LiME-formatted RAM dump
    """
    def determine_regions(memmap):
        """Extract memory regions from BIOS

        @param memmap A read-only mmap reference to the raw RAM dump
        @return sorted(mod_regions) A range-start sorted (ascending) set of memory ranges after noting mods, etc.
        """
        # handles straight BIOS declarations of memory ranges - usable, reserved, and ACPI
        bios_re = re.compile('BIOS.{1,10}\:\s\[mem\s(0x[\w\d]{16})\-(0x[\d\w]{16})\]\s(usable|reserved|ACPI\sNVS|ACPI\sdata)')
        # handles any ranges noted in BIOS as being modified
        mod_re = re.compile('update\s\[mem\s(0x[\d\w]{1,16})\-(0x[\d\w]{1,16})\]\susable\s\=\=\>\s(reserved|ACPI\sNVS|ACPI\sdata)')
        # handles ranges noted in BIOS as being removed
        rem_re = re.compile('remove\s\[mem\s(0x[\d\w]{1,16})\-(0x[\d\w]{1,16})\]\s(usable)')
        # handles "nosave" regions - ambiguous, but has to be taken into consideration to link ranges
        nosave_re = re.compile('nosave\smemory\:\s\[mem\s(0x[\d\w]{8})\-(0x[\d\w]{8})\]')
        base_regions = [SingleMap(int(r[0], 16), int(r[1], 16), r[2]) for r in list(set(bios_re.findall(memmap)))]
        possible_mods = [SingleMap(int(m[0], 16), int(m[1], 16), m[2]) for m in list(set(mod_re.findall(memmap)))]
        rems = [SingleMap(int(r[0], 16), int(r[1], 16), 'remove') for r in list(set(rem_re.findall(memmap)))]
        nosaves = [SingleMap(int(n[0], 16), int(n[1], 16), 'nosave') for n in list(set(nosave_re.findall(memmap)))]
       
        mod_regions = []
       
        # if any mod ranges are noted
        if any(possible_mods):
            for region in base_regions:
                affected_region = False # keep from inadvertently adding a range after it's been modified by another mod
                for mod in possible_mods:
                    if mod.start >= region.start and mod.stop <= region.stop: # if mod falls completely within already-noted range
                        affected_region = True
                        if mod.start == region.start: # i.e., the mod begins at the beginning of another range
                            # create two new regions, the modified region and the offset original
                            mod_regions.append(SingleMap(mod.start, mod.stop, mod.type_or_range)) 
                            mod_regions.append(SingleMap(mod.stop + 1, region.stop, region.type_or_range))
                        elif mod.stop == region.stop: # i.e., the mod ends at the end of another range
                            mod_regions.append(SingleMap(region.start, mod.start, region.type_or_range))
                            mod_regions.append(SingleMap(mod.stop + 1, region.stop, mod.type_or_range))
                        else: # i.e., if the mod falls into the middle of another range
                            # create three new ranges, i.e., the original start, the modified middle, and the remainder of the original range
                            mod_regions.append(SingleMap(region.start, mod.start - 1, region.type_or_range))
                            mod_regions.append(SingleMap(mod.start, mod.stop, mod.type_or_range))
                            mod_regions.append(SingleMap(mod.stop + 1, region.stop, region.type_or_range))
                if not affected_region: mod_regions.append(region) # if the region hasn't been modified at all just affix as is
        
        # handle regions which are noted as being removed, no noted overlaps but this is sloppy
        if any(rems):
            for rem in rems:
                mod_regions.append(rem)
        
        # handle the weird "nosave" regions, but obviate issue where an issue can be called both (e.g.) reserved and nosave
        if any(nosaves):
            for nosave in nosaves:
                if not any([m for m in mod_regions if m.start == nosave.start and m.stop == nosave.stop]): mod_regions.append(nosave)
       
        # return range start sorted regions
        return sorted(list(set(mod_regions)), key=lambda x: x.start)

    def test_regions(regions, file_size):
        """Link together regions to establish continuous range
        
        @param regions The already-modified regions from determine_regions
        @param file_size Size of raw RAM file, used to determine potential validity of memory range sequence
        """
        
        # the ranges outlined as "good" previously in challenge are just <range 0>.end + 1 == <range 1>.start
        # so for observed range, go through all potential links and create series of linked ranges
        oneupped = [] 
        for e in enumerate(regions):
            if e[0] == 0: oneupped.append([e[1]]) # first
            else:
                temp_ranges = []
                for range_set in oneupped: # go through and check each set of ranges
                    if e[1].start == range_set[-1].stop + 1: # if the range can be added to the end of the set, do so
                        temp_ranges.append(range_set[:] + [e[1]])
                    else: # if it's actually +1 of an earlier range in a set
                        for each_map in enumerate(range_set):
                            if e[1].start == each_map[1].stop + 1:
                                temp_range = range_set[:each_map[0] + 1] + [e[1]]
                                temp_ranges.append(temp_range)
                for each_range in temp_ranges: oneupped.append(each_range)
            # the next 8-10 lines can/need to be cleaned up a bit but they're working    
            temp_oneupped = []   
            for range_set_i in oneupped:
                # set().issubset() will check whether a set of ranges is a smaller version of another set, but returns True if set_a == set_b
                if any([(set(range_set_i).issubset(set(range_set_j)) and set(range_set_i) != set(range_set_j)) for range_set_j in oneupped]): continue
                else: temp_oneupped.append(range_set_i)
            oneupped = [list(r) for r in set(tuple(r) for r in temp_oneupped)]
        # these two lines can probably be rewritten to be a little more efficient    
        final_regions = list(set(tuple(r) for r in oneupped if sum(mr.stop - mr.start for mr in r if mr.type_or_range == 'usable') in range(file_size - 15, file_size + 15)))
        mapped_regions = list(set(tuple(filter(lambda r: r.type_or_range == 'usable', each_range)) for each_range in final_regions))
        return [sorted(x, key=lambda r: r.start) for x in mapped_regions] # return start-sorted list of summed usable ranges within range of file size
    
    def write_regions(mapped_regions, output_as_lime):
        """Write mapped/linked/viably-sized regions

        @param mapped_regions Set of usable ranges sequential prior to filtering of non-usable ranges, approximately file size
        @param output_as_lime The open LiME-formatted file object
        @return None No pass/fail check here - just saving to disk temporarily
        """
        offset = 0
        for each_map in mapped_regions:
            print('Writing region {} of {}'.format(mapped_regions.index(each_map) + 1, len(mapped_regions)))
            region_length = each_map.stop - each_map.start + 1
            output_as_lime.write(pack("<IIQQ8x", 0x4C694D45, 1, each_map.start, each_map.stop))
            for each_b in (memmap[x] for x in xrange(offset, offset + region_length)): # more memory-fiendly as generator
                output_as_lime.write(each_b) # writing individual bytes is slower (I think), but necessary due to limited memory
            offset += region_length
            print('Wrote region {} of {}'.format(mapped_regions.index(each_map) + 1, len(mapped_regions)))
        output_as_lime.close()    

    def validate_maps(lime_fn, args):
        """Validate LiME-formatted memory with Volatility bash command

        @param lime_fn Filename of LiME-formatted memory
        @param args Access to the full Volatility path and the Profile used to run Volatility
        @return boolean True if successful bash run, False otherwise
        """
        print('Validating {}...'.format(lime_fn))
        # run quick volatility bash command on LiME-formatted memory - if writing was valid, response will be well over 500 characters
        bash_proc = subprocess.Popen(subproc_commands['volatility']['bash'].format(args.VOL_FN, lime_fn, args.PROFILE).split(), shell=False, stdout=subprocess.PIPE)
        if len(bash_proc.communicate()[0]) > 500: return True
        return False
    
    #SingleMap = collections.namedtuple('SingleMap', ['start', 'stop', 'type_or_range'])
    input_as_raw = open(args.RAW, 'rb')
    memmap = mmap.mmap(input_as_raw.fileno(), 0, access=mmap.ACCESS_READ)
    print('Attempting to write LiME mappings of raw memory. This process can take several minutes.')
        
    # attempt to dynamically extract memory ranges from BIOS, link together, etc., and validate    
    if args.REGIONS == 'dynamic':
        file_size = os.stat(input_as_raw.name).st_size # used to filter out nonsense range combinations
        regions = determine_regions(memmap)
        mapped_regions = test_regions(regions, file_size) # need to address possibility that there are multiples
        for region_set in mapped_regions: # potential for more than one possible range, but only one in given raw RAM dump
            output_as_lime = open(os.path.join(args.OUT, 'updated.lime'), 'wb')
            write_regions(region_set, output_as_lime)
            if validate_maps(output_as_lime.name, args):
                print('Successfully wrote LiME-mapped memory to {}.'.format(output_as_lime.name))
                input_as_raw.close()
                return output_as_lime.name
            else: 
                print('Validation unsuccessful, continuing with next set of extracted regions.')
                continue
        # called if dynamic extracts are exhausted    
        print('Could not successfully do dynamic extraction of regions. Please attemp re-run with --regions=default.')
        sys.exit()
    
    # use previously-observed regions to map LiME headers        
    elif args.REGIONS == 'default':
        mapped_regions = [SingleMap(int('0x0000000000001000', 16), int('0x000000000009d7ff', 16), 'usable'),
                          SingleMap(int('0x000000000009d800', 16), int('0x000000000009ffff', 16), 'reserved'),
                          SingleMap(int('0x00000000000e0000', 16), int('0x00000000000fffff', 16), 'reserved'),
                          SingleMap(int('0x0000000000100000', 16), int('0x000000001fffffff', 16), 'usable'),
                          SingleMap(int('0x0000000020000000', 16), int('0x00000000201fffff', 16), 'reserved'),
                          SingleMap(int('0x0000000020200000', 16), int('0x0000000031498fff', 16), 'usable'),
                          SingleMap(int('0x0000000031499000', 16), int('0x00000000314dbfff', 16), 'ACPI NVS'),
                          SingleMap(int('0x00000000314dc000', 16), int('0x0000000035d7ffff', 16), 'usable'),
                          SingleMap(int('0x0000000035d80000', 16), int('0x0000000035ffffff', 16), 'reserved'),
                          SingleMap(int('0x0000000036000000', 16), int('0x0000000036741fff', 16), 'usable'),
                          SingleMap(int('0x0000000036742000', 16), int('0x00000000367fffff', 16), 'reserved'),
                          SingleMap(int('0x0000000036800000', 16), int('0x0000000036fb3fff', 16), 'usable'),
                          SingleMap(int('0x0000000036fb4000', 16), int('0x0000000036ffffff', 16), 'ACPI data'),
                          SingleMap(int('0x0000000037000000', 16), int('0x000000003871ffff', 16), 'usable'),
                          SingleMap(int('0x0000000038720000', 16), int('0x00000000387fffff', 16), 'ACPI NVS'),
                          SingleMap(int('0x0000000038800000', 16), int('0x0000000039f23fff', 16), 'usable'),
                          SingleMap(int('0x0000000039f24000', 16), int('0x0000000039fa5fff', 16), 'reserved'),
                          SingleMap(int('0x0000000039fa6000', 16), int('0x0000000039fa6fff', 16), 'usable'),
                          SingleMap(int('0x0000000039fa7000', 16), int('0x000000003e9fffff', 16), 'reserved'),
                          SingleMap(int('0x00000000f8000000', 16), int('0x00000000fbffffff', 16), 'reserved'),
                          SingleMap(int('0x00000000fec00000', 16), int('0x00000000fec00fff', 16), 'reserved'),
                          SingleMap(int('0x00000000fed00000', 16), int('0x00000000fed03fff', 16), 'reserved'),
                          SingleMap(int('0x00000000fed1c000', 16), int('0x00000000fed1ffff', 16), 'reserved'),
                          SingleMap(int('0x00000000fee00000', 16), int('0x00000000fee00fff', 16), 'reserved'),
                          SingleMap(int('0x00000000ff000000', 16), int('0x00000000ffffffff', 16), 'reserved'),
                          SingleMap(int('0x0000000100000000', 16), int('0x00000001005fffff', 16), 'usable')]
        mapped_regions = [r for r in mapped_regions if r.type_or_range == 'usable']                           
        write_regions(region_set, output_as_lime)
        if validate_maps(output_as_lime.name, args):
            print('Successfully validated LiME-mapped memory written to {}.'.format(output_as_lime.name))
            input_as_raw.close()
            return output_as_lime.name           
        else:
            print('Could not successfully write default regions. Please attemp re-run with --regions=dynamic.')
            sys.exit()

def run_basic_volatilities(args, lime_fn):
    """Run linux_bash, linux_bash_hash, linux_psaux, and linux_pslist
    
    Nested functions just run extracts over Volatility output.
    
    @param args Access to Volatility path and Profile
    @param lime_fn Filename of LiME-formatted memory output; required to run commands
    @return command_output List of pandas.DataFrame-formatted command outputs
    """
    def dump_bash(vol_response):
        headers = re.findall('(.+?)\s{2,}(.+?)\s{2,}(.+?)\s{2,}(\w+)', vol_response)[0]
        records = re.findall('\s+([\w\d]+)\s+([\w\d]+)\s+(.+?)\s{2,}(.+)', vol_response)[1:]
        return pandas.DataFrame([[v.strip() for v in r] for r in records], columns=[h.strip() for h in headers])
        
    def dump_bash_hash(vol_response):
        headers = re.findall('(.+?)\s{2,}(.+?)\s{2,}(.+?)\s{2,}(.+?)\s{2,}(\w+)', vol_response)[0]
        records = re.findall('\s+([\w\d]+)\s+([\d\w]+)\s+([\d]+)\s+([^\s]+)\s+(.+)', vol_response)
        return pandas.DataFrame([[v.strip() for v in r] for r in records], columns=[h.strip() for h in headers])
        
    def dump_psaux(vol_response):
        headers = re.findall('(.+?)\s{2,}(.+?)\s{2,}(.+?)\s{2,}(\w+)', vol_response)[0]
        records = re.findall('(\d+)\s{2,}(\d+)\s{2,}(\d+)\s{2,}(.+)', vol_response)
        return pandas.DataFrame([[v.strip() for v in r] for r in records], columns=[h.strip() for h in headers])
        
    def dump_pslist(vol_response):
        headers = re.findall('(.+?)\s{2,}(.+?)\s{2,}(.+?)\s{2,}(.+?)\s{2,}(.+?)\s{2,}(.+?)\s{2,}(.+?)\s{2,}(.+)', vol_response)[0]
        records = re.findall('([^\s]+)\s+([^\s]+)\s{2,}(\d+)\s{2,}(\d+)\s{2,}(\d+)\s{2,}(\d+)\s{2,}([^\s]+)\s(.+)', vol_response)
        return pandas.DataFrame([[v.strip() for v in r] for r in records], columns=[h.strip() for h in headers])
    
    command_logs = []
    for command in ['bash', 'bash_hash', 'psaux', 'pslist']:
        print('Grabbing {} logs'.format(command))
        command_proc = subprocess.Popen(subproc_commands['volatility'][command].format(args.VOL_FN, lime_fn, args.PROFILE).split(), shell=False, stdout=subprocess.PIPE)
        command_logs.append(command_proc.communicate()[0])
    return dump_bash(command_logs[0]), dump_bash_hash(command_logs[1]), dump_psaux(command_logs[2]), dump_pslist(command_logs[3])                              
            
def determine_mk_pid(pslist):
    """Return list of process IDs related to ovs-vswitchd
    
    @param pslist Output from linux_pslist command
    @return list List of process IDs related to ovs-vswitchd
    """
    print('Grabbing process ID of process containing Master Key information.')
    return list(pslist[pslist['Name'] == 'ovs-vswitchd']['Pid'])
            
def extract_rsa_keys(args): 
    """Search for and write RSA keys from memory dump

    @param args Access to raw RAM dump
    @return pk_files List of extracted RSA keys
    """
    print('Extracting RSA keys.')
    # 1588 wildcards within key, but newline characters increases range to 1614
    rsa_re = re.compile('\-{5}BEGIN\sRSA\sPRIVATE\sKEY\-{5}.{1614}\-{5}END\sRSA\sPRIVATE\sKEY\-{5}', re.DOTALL)
    input_as_raw = open(args.RAW, 'rb')
    memmap = mmap.mmap(input_as_raw.fileno(), 0, access=mmap.ACCESS_READ)
    private_keys = list(set(rsa_re.findall(memmap)))
    pk_files = []
    for each_key in enumerate(private_keys):
        of_name = os.path.join(args.OUT, 'ssl_{}.pem'.format(each_key[0]))
        pk_files.append(of_name)
        of = open(of_name, 'w')
        of.write(each_key[1])
        of.close()
        print('Successfully wrote {}.'.format(of_name))
    print('Extracted {} RSA keys.'.format(len(pk_files)))    
    return pk_files    

def extract_master_keys(args, rsa_keys, lime_fn, process_ids): 
    """Go between PCAP and RAM to generate Master Keys
    
    @param args Access to PCAP file, output directory, Vol path, and Profile
    @param rsa_keys List of RSA keys, used with Tshark
    @param lime_fn Filename of LiME-formatted memory    
    @param process_ids List of process IDs related to ovs-vswitchd
    @return key_fns List of Master Key filenames
    """
    print('Extracting Master Keys.')
    time_bytes = re.compile('Secure\sSockets\sLayer.+?GMT\sUnix\sTime\:\s([\d\w\s\,\:]+).+?Random\sBytes\:\s([\d\w]+)', re.DOTALL)
    #SingleFrame = collections.namedtuple('SingleFrame', ['dissected', 'frame_hex'])

    for each_key in rsa_keys:
        tshark_proc = subprocess.Popen(subproc_commands['tshark']['initial_ssl'].format(each_key, args.PCAP).split(), shell=False, stdout=subprocess.PIPE)
        tshark_response = tshark_proc.communicate()[0]
        # will only appear if correctly-written pem files are used, stop at first successful dump
        if 'SSL Record Layer: Handshake Protocol: Client Hello' in tshark_response: break

    split_ssl = tshark_response.split('\n\n')
    frame_set = [SingleFrame(f[0], f[1]) for f in zip(*[iter(split_ssl)] * 2)]

    all_clientrandoms = []
    for frame in frame_set:
        if 'SSL Record Layer: Handshake Protocol: Client Hello' in frame.dissected:
            time, random_bytes = time_bytes.findall(frame.dissected)[0]
            joined_hex = ''.join(''.join(re.findall('\s([\d\w]{2})', h)) for h in frame.frame_hex.splitlines())
            jh_key = joined_hex.find(random_bytes)
            all_clientrandoms.append(joined_hex[jh_key - 8:jh_key] + joined_hex[jh_key:jh_key + 56])
    
    all_keys = []    
    for pid in process_ids: # done in loop in off-chance that there's more than one relevant process ID (not likely)
        print('Conducting Yara search on PID {}'.format(pid))
        yara_command = subproc_commands['volatility']['mk_yara'] % (args.VOL_FN, lime_fn, args.PROFILE, pid)
        yara_proc = subprocess.Popen(yara_command.split(), shell=False, stdout=subprocess.PIPE)
        yara_base = yara_proc.communicate()[0]
        split_yara = re.sub('Task\:\sovs\-vswitchd.+', 'LINE_BREAK', yara_base).split('LINE_BREAK')[1:]
        print('Yara search returned {} possible matches.'.format(len(split_yara)))
        for each_hex in split_yara:
            joined_hex = ''.join(''.join(re.findall('\s([\d\w]{2})', h)) for h in each_hex.splitlines())
            if len(joined_hex[8:joined_hex.find('20000000')]) == 96: all_keys.append(joined_hex[8:joined_hex.find('20000000')])
    print('{} Yara results have viable lengths.'.format(len(all_keys)))        
    
    # create all possible concats
    possible_keys = [' '.join(['CLIENT_RANDOM', x, y]) for y in all_keys for x in all_clientrandoms]
    key_fns = []
    for each_key in enumerate(possible_keys):
        of_name = os.path.join(args.OUT, 'tls_{}.txt'.format(each_key[0]))
        of = open(of_name, 'w')
        of.write(each_key[1])
        of.close()
        key_fns.append(of_name)
        print('Successfully wrote {}.'.format(of_name))
    print('Extracted {} Master Keys.'.format(len(key_fns)))    
    return key_fns
    
def validate_keys(args, rsa_keys, master_keys):
    """Validates extracted keys by checking full decrypt of PCAP

    @param args Access to PCAP and REM_INV_KEYS
    @param rsa_keys List of RSA key filenames
    @param master_keys List of extracted potential Master Key files
    @return list A list of valid RSA keys, valid Master Keys, and the full decrypt of the PCAP
    """
    print('Validating all extracted keys.')
    valid_rsa_keys, valid_master_keys = [], []
    valid_response = None
    key_check = re.compile('OpenFlow\s\d\.\d\n.+\n\s+Type\:\sOFPT_.+') # only appears in properly-decrypted PCAP
    for r_key in rsa_keys:
        for m_key in master_keys:
            tshark_proc = subprocess.Popen(subproc_commands['tshark']['full_decrypt'].format(r_key, m_key, args.PCAP).split(), shell=False, stdout=subprocess.PIPE)
            tshark_response = tshark_proc.communicate()[0]
            if key_check.search(tshark_response): # if check appears in PCAP dump, both the RSA key and the Master Key are valid
                valid_rsa_keys.append(r_key)
                valid_master_keys.append(m_key)
                if not valid_response: valid_response = tshark_response # store off the first valid response
    if args.REM_INV_KEYS: # if true, automatically delete invalid keys
        for r_key in [k for k in rsa_keys if k not in valid_rsa_keys]: 
            print('Removing {}.'.format(r_key))
            os.remove(r_key)
        for m_key in [k for k in master_keys if k not in valid_master_keys]: 
            print('Removing {}.'.format(m_key))
            os.remove(m_key)
    print('Valid RSA keys: {}; Valid Master Keys: {}'.format(', '.join(set(valid_rsa_keys)), ','.join(set(valid_master_keys))))        
    return [list(set(x)) for x in (valid_rsa_keys, valid_master_keys)] + [valid_response]

def populate_pcap_tables(args, tshark_response):
    """Write flow rules table

    @param args Not actually used
    @param tshark_response Fully-decrypted PCAP dump, hex and dissected frames
    @return pandas.DataFrame Full flow rules table
    """
    def extract_from_wildcards(wildcards):
        """Handles extraction from decimal wildcards

        @param wildcards Decimal-formatted wildcards
        @return list List of in_port, dl_vlan, dl_src, dl_dst, dl_type, nw_proto, tp_src, tp_dst, src_wildcard, dst_wildcard, vlan_pcp, and nw_tos
        """
        hex_wildcards = hex(int(wildcards))[2:]
        neg_one_bin, neg_two_bin = bin(int(hex_wildcards[-1], 16))[2:].zfill(4), bin(int(hex_wildcards[-2], 16))[2:].zfill(4)
        in_port, dl_vlan, dl_src, dl_dst = neg_one_bin
        dl_type, nw_proto, tp_src, tp_dst = neg_two_bin
        src_wildcard = int(bin(int(hex_wildcards[2], 16))[2:].zfill(4) + bin(int(hex_wildcards[3], 16))[2:].zfill(4), 2) & 63
        dst_wildcard = int(bin(int(hex_wildcards[1], 16))[2:].zfill(4) + bin(int(hex_wildcards[2], 16))[2:].zfill(4), 2) & 63
        vlan_pcp, nw_tos = bin(int(hex_wildcards[0], 16))[2:].zfill(4)[-2], bin(int(hex_wildcards[0], 16))[2:].zfill(4)[-1]
        return in_port, dl_vlan, dl_src, dl_dst, dl_type, nw_proto, tp_src, tp_dst, src_wildcard, dst_wildcard, vlan_pcp, nw_tos

    def grab_extracts(frame_hex, seq_num, rem=False):
        """Handle hex component of individual frame

        @param frame_hex The hex within a given frame
        @param seq_num Sequence number, used to maintain connectivity between dissected components and hex dumps
        @param rem Used to signal that the extracts are for a flow rule removal
        @return list (src_ip, dst_ip, src_p, dst_p, action_header, and action_value) if ofpt_mod, else (wildcards, in_port, pri_two, reason, durations (2), idle_to, ip (2), port (2),
        """
        ssl_hex = re.sub('Decrypted SSL data.+', 'LINE_BREAK', frame_hex).split('LINE_BREAK')[1:][seq_num]
        joined_hex = ''.join(''.join(re.findall('\s([\d\w]{2})', h)) for h in ssl_hex.splitlines())
        if rem: # OFPT_FLOW_REMOVED has a different hex breakout
            wildcards, in_port = joined_hex[18:24], joined_hex[26:28]
            pri_two, reason = joined_hex[112:116], joined_hex[116:118]
            duration_sec, duration_nsec = joined_hex[122:128], joined_hex[128:136]
            idle_timeout = joined_hex[136:140]
            packet_count, byte_count = joined_hex[144:160], joined_hex[160:176]
        src_ip, dst_ip = joined_hex[72:80], joined_hex[81:89] # without an example dst_ip it's tough to say how they're separated
        src_port, dst_port = joined_hex[90:92], joined_hex[94:96] # these are 2-zero separated? instead of one like ip? check on this.
        if rem:
            wc_through_drops = [str(int(x, 16)) for x in (wildcards, in_port, pri_two, reason, 
                                                          duration_sec, duration_nsec, idle_timeout, packet_count, byte_count)]
            conv_src_ip, conv_dst_ip = convert_hex(src_ip, '.', 2), convert_hex(dst_ip, '.', 2)
            conv_src_p, conv_dst_p = str(int(src_port, 16)), str(int(dst_port, 16))
            return wc_through_drops + [conv_src_ip, conv_dst_ip, conv_src_p, conv_dst_p]
        joined_zeros_two = joined_hex.rstrip('0').rfind('00')
        joined_zeros_three = joined_hex.rstrip('0').rfind('000')
        if joined_zeros_three and joined_zeros_two - joined_zeros_three == 1:
            action_header = joined_hex[joined_zeros_three - 2:joined_zeros_three]
            action_value = joined_hex[joined_zeros_three + 4:].rstrip('0')
        # this doesn't fire - but also, not sure it's necessary, it looks like things are being parsed correctly and just don't match the spreadsheet    
        elif joined_zeros_three and joined_zeros_two - joined_zeros_three == 1 and re.match('0[1-9a-f]00[\d\w]+', joined_hex[joined_zeros_three - 2:]):
            action_header = joined_hex[joined_zeros_three - 2:joined_zeros_three]
            action_value = joined_hex[joined_zeros_three + 2:].rstrip('0')
        else:
            action_header = joined_hex[joined_zeros_two - 2:joined_zeros_two]
            action_value = joined_hex[joined_zeros_two + 4:].rstrip('0')
        converted_header = action_headers[int(action_header, 16)]
        if converted_header.address_type == 'decimal': converted_value = str(int(action_value, 16))
        elif converted_header.address_type == 'ethernet': converted_value = ':'.join(''.join(x) for x in zip(action_value[::2], action_value[1::2]))
        elif converted_header.address_type == 'ipaddr': converted_value = convert_hex(action_value, '.', 2)
        elif converted_header.address_type == 'hex': converted_value = action_value
        return convert_hex(src_ip, '.', 2), convert_hex(dst_ip, '.', 2), str(int(src_port, 16)), str(int(dst_port, 16)), converted_header.verbose, converted_value

    def convert_hex(hex_str, sep=None, split=None):
        """Generic to convert hex to decimal with given separator in given groups
    
        @param hex_str Raw hex string extracted from hex component of frame 
        @param sep String used to separate <x>-split groups of hex-to-decimal characters (i.e., '.' for IP address)
        @param split Number of hex-to-decimal characters to group with each other
        @return str Hex-to-decimal characters grouped on <split> and separated by <sep>
        """
        return sep.join(map(str, [int(''.join(x), 16) for x in zip(hex_str[::split], hex_str[1::split])]))

    def convert_to_dict(of_record, headers):
        """Return dictionary of header_a: of_record_a, header_b: of_record_b, etc.

        @param of_record An individual record extracted from dissectors/hex
        @param headers Record headers for a given extracted record
        @return dict A dictionary of zipped headers and record values
        """
        return dict(zip(headers, of_record))
    
    #SingleFrame = collections.namedtuple('SingleFrame', ['dissected', 'frame_hex']) # used to maintain connectivity between dissectors and hex
    ActionMap = collections.namedtuple('ActionMap', ['verbose', 'address_type', 'comment']) # used to group action headers, values, and comments
    of_re = re.compile('(OpenFlow\s\d\.\d)\s\s+.+\n\s+Type\:\s(.+)\n\s+.+\n\s+.+\n' + 
                       '\s+Wildcards\:\s(.+)\n\s+In\sport\:\s(\d+)\n\s+Ethernet\ssource\s' + 
                       'address\:\s(.+)\n\s+Ethernet\sdestination\saddress\:\s(.+)\n' + 
                       '\s+Input\sVLAN\sid\:\s(\d+)\n\s+Input\sVLAN\spriority\:\s(\d+)\n.+' + 
                       '\n.+\n.+\n.+\n.+\n.+\n.+\n\s+Command\:\s(.+)\n\s+Idle\stime\-out\:' + 
                       '\s(.+)\n\s+[Hh]ard\stime\-out\:\s(.+)\n\s+Priority\:\s(.+)\n.+\n\s+Out' + 
                       '\sport\:\s(.+)\n\s+Flags\:\s(.+)') # full regex for necessary fields from ofpt_mod record
    ofrem_re = re.compile('(OpenFlow\s\d\.\d)\n.+\n\s+Type\:\s(OFPT_FLOW_REMOVED.+)') # regex to indicate removal of flow rule

    record_headers = ['FRAME_NUMBER', 'OF_VERSION', 'OF_TYPE', 'OF_WILDCARDS', 'IN_PORT', 'ETH_SRC', 'ETH_DST', 
                      'VLAN_ID', 'VLAN_PRI', 'COMMAND', 'IDLE_TO', 'HARD_TO', 'PRI', 'OUT_PORT', 
                      'FLAGS', 'SRC_IP_EXT', 'DST_IP_EXT', 'SRC_P_EXT', 'DST_P_EXT', 'ACTION_HEADER', 'ACTION_VALUE',
                      'W_IN_PORT', 'W_VLAN_DL', 'W_DL_SRC', 'W_DL_DST', 'W_DL_TYPE', 'W_NW_PROTO', 'W_TP_SRC',
                      'W_TP_DST', 'W_SRC_WLDCD', 'W_DST_WLDCD', 'W_VLAN_PCP', 'W_NW_TOS',
                      'PRI_2', 'REASON', 'DURATION_SEC', 'DURATION_NSEC', 'PACKET_COUNT', 'BYTE_COUNT']
    action_headers = {0: ActionMap('OFPAT_OUTPUT', 'decimal', 'Output to switch port'),
                      1: ActionMap('OFPAT_SET_VLAN_VID', 'decimal', 'Set the 802.1q VLAN id'),
                      2: ActionMap('OFPAT_SET_VLAN_PCP', 'decimal', 'Set the 802.1q priority'),
                      3: ActionMap('OFPAT_STRIP_VLAN', 'decimal', 'Strip the 802.1q header'),
                      4: ActionMap('OFPAT_SET_DL_SRC', 'ethernet', 'Ethernet source address'),
                      5: ActionMap('OFPAT_SET_DL_DST', 'ethernet', 'Ethernet destination address'),
                      6: ActionMap('OFPAT_SET_NW_SRC', 'ipaddr', 'IP source address'),
                      7: ActionMap('OFPAT_SET_NW_DST', 'ipaddr', 'IP destination address'),
                      8: ActionMap('OFPAT_SET_NW_TOS', 'hex', 'IP ToS (DSCP field, 6 bits)'),
                      9: ActionMap('OFPAT_SET_TP_SRC', 'decimal', 'TCP/UDP source port'),
                      10: ActionMap('OFPAT_SET_TP_DST', 'decimal', 'TCP/UDP destination port'),
                      11: ActionMap('OFPAT_ENQUEUE', 'decimal', 'Output to queue'),
                      12: ActionMap('OFPAT_VENDOR', 'decimal', '')}

    split_text = tshark_response.split('\n\n')
    frame_set = [SingleFrame(f[0], f[1]) for f in zip(*[iter(split_text)] * 2)]

    final_df, matched_frames = [], []
    for frame in frame_set:
        of_matches = of_re.findall(frame.dissected)
        ofrem_matches = ofrem_re.findall(frame.dissected)
        if any(of_matches):
            action_maps = []
            of_records = []
            for of_split in enumerate(frame.dissected.split('OpenFlow')[1:]):
                if 'Data not dissected yet' in of_split[1]: # do join/strip here
                    final_df.append(dict(zip(['FRAME_NUMBER', 'OF_VERSION', 'OF_TYPE', 'OF_WILDCARDS', 'IN_PORT', 'ETH_SRC', 'ETH_DST',
                                              'VLAN_ID', 'VLAN_PRI', 'COMMAND', 'IDLE_TO', 'HARD_TO', 'PRI', 'OUT_PORT', 'FLAGS',
                                              'SRC_IP_EXT', 'DST_IP_EXT', 'SRC_P_EXT', 'DST_P_EXT', 'ACTION_HEADER', 'ACTION_VALUE',
                                              'W_IN_PORT', 'W_VLAN_DL', 'W_DL_SRC', 'W_DL_DST', 'W_DL_TYPE', 'W_NW_PROTO', 'W_TP_SRC',
                                              'W_TP_DST', 'W_SRC_WLDCD', 'W_DST_WLDCD', 'W_VLAN_PCP', 'W_NW_TOS'],
                                             itertools.chain.from_iterable([[frame_set.index(frame) + 1], of_matches[of_split[0]], 
                                                                             grab_extracts(frame.frame_hex, of_split[0]), 
                                                                             extract_from_wildcards(of_matches[of_split[0]][2])]))))
        elif any(ofrem_matches) and frame_set.index(frame) not in matched_frames:
            for of_split in enumerate(frame.dissected.split('OpenFlow')[1:]):
                if 'not dissected yet' in of_split[1]:
                    extracts = grab_extracts(frame.frame_hex, of_split[0], rem=True)
                    final_df.append(dict(zip(['FRAME_NUMBER', 'OF_VERSION', 'OF_TYPE', 'OF_WILDCARDS', 'IN_PORT', 'PRI_2', 
                                              'REASON', 'DURATION_SEC', 'DURATION_NSEC', 'IDLE_TO', 'PACKET_COUNT', 'BYTE_COUNT', 
                                              'SRC_IP_EXT', 'DST_IP_EXT', 'SRC_P_EXT', 'DST_P_EXT', 'W_IN_PORT', 'W_VLAN_DL', 
                                              'W_DL_SRC', 'W_DL_DST', 'W_DL_TYPE', 'W_NW_PROTO', 'W_TP_SRC',
                                              'W_TP_DST', 'W_SRC_WLDCD', 'W_DST_WLDCD', 'W_VLAN_PCP', 'W_NW_TOS'],
                                             itertools.chain.from_iterable([[frame_set.index(frame) + 1], ofrem_matches[of_split[0]], 
                                                                             extracts, extract_from_wildcards(extracts[0])]))))
    return pandas.DataFrame(final_df, columns=record_headers)

def populate_dump_tables(args, log_df):
    def prepare_dataframe(logs_df):
        """Initializes dataframe for use in rest of script; converts DTG and dedupes
    
        @param logs_df DataFrame of log values grabbed from strings
        @return log_dataframe.drop_duplicates() Completely unique rows within log
        """
        log_dataframe = log_df.dropna()
        log_dataframe.DTG = log_dataframe.DTG.apply(lambda x: datetime.datetime.strptime(x, '%Y-%m-%dT%H:%M:%S.%fZ'))
        return log_dataframe.drop_duplicates()

    def generate_counts(log_df, log_key):
        """Used to generate counts of a particular key within log dataframe
    
        @param log_df Deduped dataframe of log records
        @param log_key Column to group on 
        @return agg Grouped counts of <log_key>
        """
        return pandas.DataFrame([(each_group[0], len(each_group[1])) for each_group in log_df.groupby(log_key)], columns=[log_key, 'TYPE_COUNT'])

    def generate_extracts(log_df, log_type, extract_str, keep_dtg=False):
        """Generate subset of log_df based on column/log_type and an extract string

        @param log_df Deduped dataframe of log records
        @param log_type Column to filter on
        @param extract_str Regex for what to extract from LOG_DESC
        @param keep_dtg Used to maintain/drop DTG from returned DF/output tab - "implemented" but not really, vestige of last version
        @return trimmed_dataframe Subset DF with/without DTG
        """
        trimmed_dataframe = log_df[log_df.LOG_TYPE == log_type]
        extracts = trimmed_dataframe.LOG_DESC.str.extract(extract_str)
        extracts = extracts if isinstance(extracts, pandas.DataFrame) else pandas.DataFrame(extracts)
        for each_column in extracts:
            trimmed_dataframe['EXTRACT_{}'.format(each_column)] = extracts[each_column]
        trimmed_dataframe = trimmed_dataframe[['DTG'] + [column for column in trimmed_dataframe if 'EXTRACT' in column]].dropna().drop_duplicates()
        trimmed_dataframe = trimmed_dataframe if keep_dtg else trimmed_dataframe[[c for c in trimmed_dataframe.columns if 'EXTRACT' in c]].drop_duplicates()
        return trimmed_dataframe

    def stdout_stats(log_df, **kwargs):
        """Print log stats to stdout.
    
        @param log_df Deduped log dataframe
        @param kwargs Used to extend output 
        """
        def extract_helper(print_str=None, logs=None):
            """Generic to print extracts along with description.

            @param print_str Description injected into output 
            @param logs Subset DF passed from controlling function
            """
            if isinstance(logs, pandas.DataFrame):
                print('Observed {}:\n\t{}'.format(print_str, '\n\t'.join([' | '.join(map(str, v)) for v in logs.values])))
        
        print('Number of unique log entries: {}'.format(len(log_df)))
        print('Log first-heard: {}'.format(log_df.DTG.min()))
        print('Log last-heard: {}'.format(log_df.DTG.max()))
        print('Log time delta: {}'.format(log_df.DTG.max() - log_df.DTG.min()))
        print('Observed log entry types:\n\t{}'.format('\n\t'.join(': '.join(map(str, (t, c))) for t,c in kwargs.get('type_counts').values)))
        extract_helper('OVS versions', kwargs.get('ovsv'))
        extract_helper('.pem files', kwargs.get('pem_fn'))
        extract_helper('cert fingerprints', kwargs.get('pem_fp'))
        extract_helper('connmgr additions (add/remove, type, addr)', kwargs.get('connmgr_add'))
        extract_helper('connmgr removals (add/remove, type, addr)', kwargs.get('connmgr_rem'))
        extract_helper('interface additions (add/remove, if, port)', kwargs.get('if_add'))
        extract_helper('interface removals (add/remove, if, port)', kwargs.get('if_rem'))

    extracts = {'ovsv': '(.*)', 'connmgr': 'br[0-9]{1,}:\s(.+?)\s(.+?)\s.+\s(\".*\")',
                'pem_fn': '(/.*\.pem)', 'pem_fp': '\(fingerprint\s(.*)\)',
                'if': 'bridge br[0-9]{1,}\:\s(.+?)\s.+\s(.+?)\s.+\s.+\s(.+)'}

    log_dataframe = prepare_dataframe(log_df)
    type_count_df = generate_counts(log_dataframe, 'LOG_TYPE')
    ovsv_df = generate_extracts(log_dataframe, 'ovsdb_server', extracts['ovsv'], keep_dtg=args.KEEP_DTG)
    pem_fn_df = generate_extracts(log_dataframe, 'stream_ssl', extracts['pem_fn'], keep_dtg=args.KEEP_DTG)
    pem_fp_df = generate_extracts(log_dataframe, 'stream_ssl', extracts['pem_fp'], keep_dtg=args.KEEP_DTG)
    connmgr_log_df = generate_extracts(log_dataframe, 'connmgr', extracts['connmgr'], keep_dtg=args.KEEP_DTG)
    if_log_df = generate_extracts(log_dataframe, 'bridge', extracts['if'], keep_dtg=args.KEEP_DTG)
    if args.STDOUT_RAM:
        stdout_stats(log_dataframe, type_counts=type_count_df, 
                     ovsv=ovsv_df, pem_fn=pem_fn_df, pem_fp=pem_fp_df,
                     connmgr_add=connmgr_log_df[connmgr_log_df.EXTRACT_0 == 'added'],
                     connmgr_rem=connmgr_log_df[connmgr_log_df.EXTRACT_0 == 'removed'],
                     if_add=if_log_df[if_log_df.EXTRACT_0 == 'added'],
                     if_rem=if_log_df[if_log_df.EXTRACT_0 == 'removed'])
    return log_dataframe, type_count_df, ovsv_df, pem_fn_df, pem_fp_df, connmgr_log_df, if_log_df         

def identify_hosts(tshark_response, bash):
    """Returns maps of hosts, vswitches, and controllers

    @param tshark_response A decrypted and fully valid breakout of PCAP
    @param bash A DataFrame containing bash logs
    @return distributed_maps Hostname-containing maps with IPv4/IPv6, MAC, and In Port
    @return vswitch_maps Maps holding information concerning vswitches; port number, mac, and port name
    @return controller_maps Maps containing information concerning the OVS controller
    """
    def distribute_maps(mac_maps, port_maps, temp_host_maps):
        """Returns zipped-up MACs, ports, IP addresses, and hostnames
        
        @param mac_maps Maps of MAC to IP addresses
        @param port_maps Maps of In Ports to MAC addresses
        @param temp_host_maps Maps of auth/ptr resolutions to MAC addresses
        @return host_maps Parameters zipped-up in HostName namedtuple
        """
        def none_helper(map_value):
            """Returns the param if it exists, else an empty list, useful for filter/map/etc"""
            return map_value if map_value else []
            
        host_maps = []
        for each_mac in mac_maps:
            ipv4, ipv6 = map(lambda ip_key: ', '.join(filter(lambda each_ip: re.search(ip_key, each_ip), none_helper(mac_maps.get(each_mac, None)))), ['\.', '\:'])
            ports = ', '.join(none_helper(mac_maps.get(each_mac, None)))
            host_maps.append(HostMap(temp_host_maps.get(each_mac, 'None Observed'), 
                             ipv4 if ipv4 != '' else 'None Observed', ipv6 if ipv6 != '' else 'None Observed',
                             each_mac,
                             ports if ports != '' else 'None Observed'))
        return host_maps                     
                
    frame_set = [SingleFrame(f[0], f[1]) for f in zip(*[iter(tshark_response.split('\n\n'))] * 2)]
    eth_ip_re = re.compile('OpenFlow\s\d\.\d.{0,}\n(?:.+\n)+?\s+Ethernet.+?Src\:\s(.+?)\,\sDst\:\s(?:.+\n)+?\s+Internet\sProtocol\s.+?Src\:\s(.+?)\,\sDst\:\s.+')
    all_maps = [m for m in [eth_ip_re.findall(f.dissected) for f in frame_set] if any(m)]
    deduped_maps = list(set(itertools.chain.from_iterable(all_maps)))
    mac_maps = {mac: [each_map[1] for each_map in deduped_maps if each_map[0] == mac and re.search('\d|\w', each_map[1])] 
                for mac in set(each_map[0] for each_map in deduped_maps)}
    
    port_maps, temp_host_maps = {}, {}
                             
    for each_mac in mac_maps:
        ports, domain_names = [], []
        port_map_re = re.compile('\s+In\sport\:\s(.+)\n(?:.+\n)+?\s+Ethernet\sII\,\sSrc\:\s{}\,.+'.format(re.escape(each_mac)))
        auth_ns_re = re.compile('OpenFlow(?:.+\n)+?\s+Ethernet\sII\,\sSrc\:\s({})\,.+\n(?:.+\n)+\s+Multicast\sDomain\sName\s'.format(re.escape(each_mac)) + 
                                 'System(?:.+\n)+?\s+Authoritative\snameservers\n\s+([^\:]+)\:\s(?:.+)addr\s.+')
        ptr_ns_re = re.compile('OpenFlow(?:.+\n)+?\s+Ethernet\sII\,\sSrc\:\s({})\,.+\n(?:.+\n)+\s+Multicast\sDomain\sName\s'.format(re.escape(each_mac)) + 
                               'System.+\n(?:.+\n)+?\s+Questions:\s0.{0,}\n(?:.+\n)+?\s+Domain\sName\:\s(.+)')
        for each_frame in frame_set:
            ports.append(list(set(match for match in itertools.chain.from_iterable(port_map_re.findall(each_frame.dissected)) if any(match))))
            
            auth_matches = auth_ns_re.findall(each_frame.dissected)
            ptr_matches = ptr_ns_re.findall(each_frame.dissected)
            domain_names.append([match[1] for match in auth_matches if match[0] == each_mac] + [match[1] for match in ptr_matches if match[0] == each_mac])
            
        port_maps.setdefault(each_mac, list(set(itertools.chain.from_iterable(ports))))
        temp_host_maps.setdefault(each_mac, list(set(itertools.chain.from_iterable(domain_names))))
        
    vswitch_re = re.compile('\s+Port\snumber\:\s(\d+)\n\s+HW\sAddress\:\s(.+)\n\s+Port\sName\:\s(.+)') 
    vswitch_maps = [VswitchMap(m[0], m[1], m[2]) for m in list(set(match for match in itertools.chain.from_iterable(vswitch_re.findall(f.dissected) 
                                                                                                                    for f in frame_set) if any(match)))]
    controller_maps = [ControllerMap(m[0], m[1]) for m in bash.Command.str.extract('ovs\-vsctl\sset\-controller\s(\S+)\s(?:[^\:]+)\:([^\:]+)\:(?:.+)').dropna().drop_duplicates().values]
    distributed_maps = distribute_maps(mac_maps, port_maps, temp_host_maps)
    
    return distributed_maps, vswitch_maps, controller_maps
    
def grab_n_packets(raw_strings):
    """Grab dump-flows output from strings

    @param raw_strings Output from strings command
    @return list List of DumpMap namedtuples containing n_packets, n_bytes, in_port, dl_dst, and actions
    """
    dumps = list(set(re.findall('.+?n_packets\=(\d+).+?n_bytes\=(\d+).+?in\_port\=(\d+).+?dl\_dst\=(\S+)\sactions\=(output\:\d+)', raw_strings)))
    return [DumpMap(each_dump[0], each_dump[1], each_dump[2], each_dump[3], each_dump[4]) for each_dump in dumps]

def grab_controller(bash):
    """Simple search for ryu-manager strings"""
    return [' '.join([x, y]) for x, y in bash.Command.str.extract('ryu-manager\s([^\/]+)\/[^\/]+?\/([^\.]+)').dropna().drop_duplicates().values]

def handle_not_lime():
    """Failure state, exits program. No LiME dump, and no indication of LiME use in strings"""
    print('No information concerning dump to raw RAM structure. Cannot convert or proceed. Exiting.')
    sys.exit()

def dump_filesystem(args, lime_fn):
    """Recovers filesystem

    @param args Access to output directory
    @param lime_fn Full path of converted/supplied LiME-formatted file
    @return files_of_interest List of files that may be worth further analyzing in recovered system
    """
    dump_dir = os.path.join(args.OUT, 'recovered_filesystem')
    os.mkdir(dump_dir)
    print('Dumping recovered filesystem to {}; this may take a while (10-15+ minutes)'.format(dump_dir))
    try:
        filesystem_proc = subprocess.Popen(subproc_commands['volatility']['recover_fs'].format(args.VOL_FN, lime_fn, args.PROFILE, dump_dir).split(),
                                           shell=False, stdout=subprocess.PIPE).communicate()
        chmod_proc = subprocess.Popen('sudo chmod -R 777 {}'.format(dump_dir).split(), shell=False, stdout=subprocess.PIPE).communicate()
        files_of_interest = [os.path.join(path, fn) for path, folders, files in os.walk(dump_dir) for fn in files if 'log' or 'ovs' in fn]
        return files_of_interest
    except Exception as e:
        print('Error recovering filesystem: {}. Continuing script.'.format(e))
        return None

def dump_question_one(args, controller_info, ovs_info):
    """Dumps information pertaining to question one of competition

    @param args Access to output directory
    @param controller_info Scraped information concerning controller
    @param ovs_info List of observed OVS versions
    @return None
    """
    q1_output = open(os.path.join(args.OUT, 'Question_One_Summary.txt'), 'w')
    q1_output.write('Controller Information: {}\n'.format('; '.join(controller_info)))
    q1_output.write('OVS Version: {}\n'.format('; '.join([str(v) for v in ovs_info.EXTRACT_LOG_DESC])))
    q1_output.close()
    
def dump_question_two(args, controller_maps, distributed_maps, flow_rules_df, vswitch_maps): 
    """Dumps information pertaining to question two of competition
    
    @param args Access to output directory
    @param controller_maps Maps of Name, IPAddr
    @param distributed_maps Maps of Hostname, IPv4, IPv6, MAC, and In Port
    @param flow_rules_df DataFrame of observed flow rules from PCAP
    @param vswitch_maps Maps of Port Number, MAC, and Port Name
    @return None
    """
    q2_output = open(os.path.join(args.OUT, 'Question_Two_Summary.txt'), 'w')
    q2_output.write('Controller information:\n')
    for each_controller in controller_maps:
        q2_output.write('\tName: {}\n\tIP Address: {}\n\n'.format(each_controller.name, each_controller.ip_addr))
    q2_output.write('\nConnected hosts:\n')
    for each_dist in distributed_maps:
        q2_output.write('Hostname: {}\n\tIPv4 Address: {}\n\tIPv6 Address: {}\n\tMAC Address: {}\n\tIn Port: {}\n\n'.format(each_dist.hostname, each_dist.ipv4,
                                                                                                                          each_dist.ipv6, each_dist.mac, each_dist.in_port))
    q2_output.write('\nVSwitch information:\n')
    for each_vswitch in vswitch_maps:
        q2_output.write('Port Number: {}\n\tMAC Address: {}\n\tPort Name: {}\n\n'.format(each_vswitch.port_number, each_vswitch.mac, each_vswitch.port_name))
    
    reachable_hosts = [(x, y) for x, y in flow_rules_df[flow_rules_df.OF_TYPE == 'OFPT_FLOW_MOD (14)'][['SRC_IP_EXT', 'IN_PORT']].drop_duplicates().values]
    q2_output.write('\nReachable hosts:\n')
    for each_pair in reachable_hosts:
        q2_output.write('\tSrc IP: {}\n\tIn Port: {}\n\n'.format(each_pair[0], each_pair[1]))
    q2_output.close()        

def dump_question_three(args, flow_rules_df, dump_flows):
    """Dumps information pertaining to question two of competition
    
    @param args Access to output directory
    @param flow_rules_df DataFrame of observed flow rules from PCAP
    @param dump_flows Maps of n_packet, n_bytes, etc.
    @return None
    """
    q3_output = open(os.path.join(args.OUT, 'Question_Three_Summary.txt'), 'w')
    filtered_flows = flow_rules_df[flow_rules_df.OF_TYPE == 'OFPT_FLOW_REMOVED (11)'][['SRC_IP_EXT', 'PACKET_COUNT', 'BYTE_COUNT']]
    q3_output.write('PCAP/Flow Rules Metrics:\n')
    for ip, packets, bytes in filtered_flows.values:
        q3_output.write('\tSrc IP: {}\n\tPacket Count: {}\n\tByte Count: {}\n\n'.format(ip, packets, bytes))
    q3_output.write('\nObserved in dump-flows:\n')
    for dump_map in dump_flows:
        q3_output.write('\tPacket Count: {}\n\tByte Count: {}\n\tIn Port: {}\n\tDL Dest: {}\n\tActions: {}\n\n'.format(dump_map.n_packets, dump_map.n_bytes,
                                                                                                                       dump_map.in_port, dump_map.dl_dst,
                                                                                                                       dump_map.actions))
    q3_output.close()                                                                                                                       

def write_spreadsheet(args, data, name):
    """Dump <dataframe> to CSV

    @param args Access to output directory
    @param data A DataFrame extracted during course of script
    @param name Filename of output
    @return None
    """
    output_fn = os.path.join(args.OUT, '{}.csv'.format(name))
    data.to_csv(output_fn, sep=',', index=None)
        
def dump_text(args, strings, name):
    """Simple dump of text/list to text

    @param args Access to output directory
    @param strings The strings to dump
    @param name The name of the output file
    @return None
    """
    output_fn = open(os.path.join(args.OUT, '{}.txt'.format(name)), 'w')
    if isinstance(strings, list):
        output_fn.write('\n'.join([l for l in strings]))
    else: output_fn.write(strings)
    output_fn.close()

if __name__ == '__main__': 
    arguments = parse_commandline()
    validate_externals(arguments)
    strings = grab_strings(arguments) # save these off
    os_info, dump_files = grab_insmod_info(strings)
    if not any([os_info, dump_files]) and not args.LIME_FN: handle_not_lime()
    lime_fn = convert_raw(arguments) if not arguments.LIME_FN else arguments.LIME_FN
    log_df = grab_logs(strings)
    bash, bash_hash, psaux, pslist = run_basic_volatilities(arguments, lime_fn)
    pids = determine_mk_pid(pslist)
    rsa_files = extract_rsa_keys(arguments)
    master_keys = extract_master_keys(arguments, rsa_files, lime_fn, pids)
    valid_rsa_keys, valid_master_keys, valid_response = validate_keys(arguments, rsa_files, master_keys)
    flow_rules_df = populate_pcap_tables(arguments, valid_response)
    log_df, type_count_df, ovsv_df, pem_fn_df, pem_fp_df, connmgr_log_df, if_log_df = populate_dump_tables(arguments, log_df)
    if arguments.DUMP_FS: files_of_interest = dump_filesystem(arguments, lime_fn)
    distributed_maps, vswitch_maps, controller_maps = identify_hosts(valid_response, bash)
    dump_question_one(arguments, grab_controller(bash), ovsv_df)
    dump_question_two(arguments, controller_maps, distributed_maps, flow_rules_df, vswitch_maps)
    dump_question_three(arguments, flow_rules_df, grab_n_packets(strings))
    write_spreadsheet(arguments, bash, 'bash_history')
    write_spreadsheet(arguments, bash_hash, 'bash_hash')
    write_spreadsheet(arguments, psaux, 'psaux')
    write_spreadsheet(arguments, pslist, 'pslist')
    write_spreadsheet(arguments, log_df, 'log_summary')
    write_spreadsheet(arguments, type_count_df, 'type_counts')
    write_spreadsheet(arguments, ovsv_df, 'ovs_versions')
    write_spreadsheet(arguments, pem_fn_df, 'pem_filenames')
    write_spreadsheet(arguments, pem_fp_df, 'pem_fingerprints')
    write_spreadsheet(arguments, connmgr_log_df, 'connection_manager')
    write_spreadsheet(arguments, if_log_df, 'interface_log')
    write_spreadsheet(arguments, flow_rules_df, 'flow_table')
    if arguments.DUMP_FS and files_of_interest: dump_text(arguments, files_of_interest, 'possible_recovered_files_of_interest')
    dump_text(arguments, strings, 'strings')
    dump_text(arguments, os_info, 'os')
    dump_text(arguments, dump_files, 'observed_dumps')
    